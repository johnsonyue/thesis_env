#include "uniform.h"

Uniform uniform2Pi(0, 6.28);

